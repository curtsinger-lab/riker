from bashlex import flags, utils

parserstate = lambda: utils.typedset(flags.parser)
