## Install

```
$ pip3 install -r requirements.txt
```

## Run

```
$ ./rewrite_shell <program.sh>
```
