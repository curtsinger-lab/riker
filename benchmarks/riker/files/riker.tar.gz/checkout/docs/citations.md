# Citation Ideas
Include these in the PAPER

[https://eng.uber.com/go-monorepo-bazel/]  
It took Uber engineers significant effort to port a Go build to Bazel. Go is much more build-friendly than C/C++, and even this was a major undertaking.

[https://dl.acm.org/doi/abs/10.1109/ICSE.2019.00125]
Detecing incorrect build rules.
