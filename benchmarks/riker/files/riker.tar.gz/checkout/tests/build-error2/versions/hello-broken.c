#include <stdio.h>

extern void print_world();

int main() {
  printf("Hello ")
  print_world();
  return 0;
}
