#include <stdio.h>

void print_world() {
  printf("world.\n");
}
