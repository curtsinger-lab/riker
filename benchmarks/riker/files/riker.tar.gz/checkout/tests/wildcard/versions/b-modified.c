#include <stdio.h>

void b() {
  printf("Goodbye from b.\n");
}
