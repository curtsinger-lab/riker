#include <stdio.h>

void a() {
  printf("Hello from a.\n");
}
