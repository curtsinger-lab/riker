#include <stdio.h>

void a() {
  printf("Goodbye from a.\n");
}
