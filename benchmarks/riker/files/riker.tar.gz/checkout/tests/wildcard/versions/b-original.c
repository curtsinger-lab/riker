#include <stdio.h>

void b() {
  printf("Hello from b.\n");
}
