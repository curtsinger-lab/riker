#include <stdio.h>

void c() {
  printf("Hello from c.\n");
}
