#include <stdio.h>

void c() {
  printf("Goodbye from c.\n");
}
