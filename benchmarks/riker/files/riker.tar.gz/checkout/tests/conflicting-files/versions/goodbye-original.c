#include <stdio.h>

void say_goodbye() {
  printf("Goodbye.\n");
}
