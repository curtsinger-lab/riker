#include <stdio.h>

void say_goodbye();

int main() {
  printf("Hello!\n");

  say_goodbye();

  return 0;
}
