#pragma once

#define HELLO "hello"

void hello();