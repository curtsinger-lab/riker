#pragma once

#define FOO "foo"

void foo();
