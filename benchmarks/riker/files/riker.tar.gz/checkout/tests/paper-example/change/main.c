#include "x.h"
#include "y.h"
#include "z.h"
#include <stdio.h>

int main() {
    hello();
    printf(" ");
    world();
    printf("!\n");
    foo();
    printf("\n");
    return 0;
}
