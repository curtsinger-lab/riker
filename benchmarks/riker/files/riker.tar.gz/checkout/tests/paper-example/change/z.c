#include "z.h"
#include <stdio.h>

void foo() {
    printf(FOO);
}
