#pragma once

#define WORLD "world"

void world();