#include "y.h"
#include <stdio.h>

void world() {
    printf(WORLD);
}