#include "x.h"
#include <stdio.h>

void hello() {
    printf(HELLO);
}