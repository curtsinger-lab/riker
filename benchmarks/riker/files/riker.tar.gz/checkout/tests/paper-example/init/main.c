#include "x.h"
#include "y.h"
#include <stdio.h>

int main() {
    hello();
    printf(" ");
    world();
    printf("!\n");
    return 0;
}