#include <stdio.h>

int main() {
  printf("Goodbye world\n");
  return 0;
}
