#pragma once

void terminate() noexcept;
